package com.example.winequalitypredictionspark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WineQualityPredictionSparkApplicationTests {

    @Test
    void contextLoads() {
    }

}
