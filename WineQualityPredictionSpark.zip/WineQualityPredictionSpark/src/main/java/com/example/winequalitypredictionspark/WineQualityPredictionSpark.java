import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.DecisionTreeRegressionModel;
import org.apache.spark.ml.regression.DecisionTreeRegressor;
import org.apache.spark.ml.evaluation.RegressionEvaluator;
import org.apache.spark.ml.feature.VectorIndexer;
import org.apache.spark.ml.feature.VectorSelector;
import org.apache.spark.ml.tuning.CrossValidator;
import org.apache.spark.ml.tuning.CrossValidatorModel;
import org.apache.spark.ml.tuning.ParamGridBuilder;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import scala.collection.mutable.WrappedArray;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WineQuality {

    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("WineQuality")
                .master("local[*]")
                .getOrCreate();

        // Step 2: Load the wine quality dataset from a CSV file
        Dataset<Row> data = spark.read().format("csv")
                .option("header", "true")
                .option("inferSchema", "true")
                .load("winequality-red.csv");

        // For simplicity, let's assume the 'quality' column is the target variable
        Dataset<Row> features = data.selectExpr("cast(fixed_acidity as double) fixedAcidity",
                "cast(volatile_acidity as double) volatileAcidity",
                "cast(citric_acid as double) citricAcid",
                "cast(residual_sugar as double) residualSugar",
                "cast(chlorides as double) chlorides",
                "cast(free_sulfur_dioxide as double) freeSulfurDioxide",
                "cast(total_sulfur_dioxide as double) totalSulfurDioxide",
                "cast(density as double) density",
                "cast(pH as double) pH",
                "cast(sulphates as double) sulphates",
                "cast(alcohol as double) alcohol");

        Dataset<Row> labels = data.select("quality");

        // Step 3a: Feature selection using VectorSelector (you can choose the number of features)
        VectorSelector selector = new VectorSelector()
                .setInputCols(new String[]{"fixedAcidity", "volatileAcidity", "citricAcid",
                        "residualSugar", "chlorides", "freeSulfurDioxide"})
                .setOutputCol("features");

        Dataset<Row> selectedFeatures = selector.transform(features);

        // Step 3b: Data preprocessing - Standardize the features
        VectorIndexer indexer = new VectorIndexer()
                .setInputCol("features")
                .setOutputCol("indexedFeatures")
                .setMaxCategories(4);

        Dataset<Row> indexedData = indexer.fit(selectedFeatures).transform(selectedFeatures);

        // Step 4: Split the dataset into training and testing sets
        Dataset<Row>[] split = indexedData.randomSplit(new double[]{0.8, 0.2});
        Dataset<Row> trainData = split[0];
        Dataset<Row> testData = split[1];

        // Step 5: Create and train a linear regression model with hyperparameter tuning
        LinearRegression lr = new LinearRegression()
                .setMaxIter(10)
                .setRegParam(0.3)
                .setElasticNetParam(0.8);

        ParamGridBuilder gridBuilder = new ParamGridBuilder()
                .addGrid(lr.fitIntercept(), new boolean[]{true, false});

        CrossValidator cv = new CrossValidator()
                .setEstimator(lr)
                .setEstimatorParamMaps(gridBuilder.build())
                .setNumFolds(5);

        CrossValidatorModel cvModel = cv.fit(trainData);

        // Step 6: Evaluate the model's performance
        LinearRegressionModel lrModel = cvModel.bestModel().asInstanceOf(LinearRegressionModel.class);
        Dataset<Row> predictions = lrModel.transform(testData);

        RegressionEvaluator evaluator = new RegressionEvaluator()
                .setLabelCol("quality")
                .setPredictionCol("prediction")
                .setMetricName("r2");

        double r2 = evaluator.evaluate(predictions);
        System.out.println("R-squared: " + r2);

        // Step 7: Make predictions
        // You can use the trained model to make predictions for new data

        // Step 10: Print confusion matrix
        // This is not directly supported in MLlib, but you can implement it manually

        // Step 5: Create and train a Decision Tree model with hyperparameter tuning
        DecisionTreeRegressor dt = new DecisionTreeRegressor()
                .setMaxDepth(5)
                .setMinInstancesPerNode(10)
                .setMinInfoGain(0.0);

        ParamGridBuilder dtGridBuilder = new ParamGridBuilder()
                .addGrid(dt.maxDepth(), new int[]{3, 5, 7, 10})
                .addGrid(dt.minInstancesPerNode(), new int[]{2, 5, 10})
                .addGrid(dt.minInfoGain(), new double[]{0.0, 0.1, 0.2});

        CrossValidator dtCv = new CrossValidator()
                .setEstimator(dt)
                .setEstimatorParamMaps(dtGridBuilder.build())
                .setNumFolds(5);

        CrossValidatorModel dtCvModel = dtCv.fit(trainData);

        // Step 6: Evaluate the model's performance
        DecisionTreeRegressionModel dtModel = dtCvModel.bestModel().asInstanceOf(DecisionTreeRegressionModel.class);
        Dataset<Row> dtPredictions = dtModel.transform(testData);

        RegressionEvaluator dtEvaluator = new RegressionEvaluator()
                .setLabelCol("quality")
                .setPredictionCol("prediction")
                .setMetricName("r2");

        double dtR2 = dtEvaluator.evaluate(dtPredictions);
        System.out.println("Decision Tree R-squared: " + dtR2);

        spark.stop();
    }
}